import React, { Component } from "react";
import ClassComp from "./components/classComp";
import FunComp from "./components/funComp";
import PureClassComp from "./components/pureClassComp";
import MemoFunComp from "./components/memoComp";

class App extends Component{
    state = {
        power : "0"
    }
    render(){
        return <div className="container">
                    <h1>Hello React</h1>
                    <input onChange={(event) => this.setState({ power : event.target.value })} className="mb-2" type="number" />
                    <br />
                    <button onClick={() => this.setState({ power : 10 })} className="btn btn-warning mb-2">Set Power to 10</button>
                    <hr />
                    <ClassComp power={this.state.power} title={this.state.title}/>
                    <FunComp power={this.state.power} title={this.state.title}/>
                    <PureClassComp power={this.state.power} title={this.state.title}/>
                    <MemoFunComp power={this.state.power} title={this.state.title}/>
                </div>
        }
}

export default App;