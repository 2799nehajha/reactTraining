let FunComp = (props) => {
        console.log("FunComp was rendered");
        return <div>
                    <h4>Function Component</h4>
                    <h5>Power : {props.power}</h5>
               </div>
  }

export default FunComp;