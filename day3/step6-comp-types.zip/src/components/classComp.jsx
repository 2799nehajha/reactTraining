import { Component } from "react";

class ClassComp extends Component{
    /* 
    shouldComponentUpdate(){
        if(arguments[0].power == "10"){
            return false
        }else{
            return true
        }
    } 
    */
    render(){
        console.log("ClassComp was rendered");
        return <div>
                    <h4>Class Component</h4>
                    <h5>Power : {this.props.power}</h5>
               </div>
    }
}

export default ClassComp;