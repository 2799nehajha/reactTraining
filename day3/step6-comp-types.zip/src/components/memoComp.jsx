import { memo } from "react";

let MemoFunComp = (props) => {
    console.log("Memo FunComp was rendered");
    return <div>
                <h4>Memo Function Component</h4>
                <h5>Power : {props.power}</h5>
           </div>
}
// HOC
export default memo(MemoFunComp);