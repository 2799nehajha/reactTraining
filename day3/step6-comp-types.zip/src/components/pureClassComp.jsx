import { PureComponent } from "react";

class PureClassComp extends PureComponent{
    render(){
        console.log("Pure Class Comp was rendered");
        return <div>
                    <h4>Pure Class Component</h4>
                    <h5>Power : {this.props.power}</h5>
               </div>
    }
}
export default PureClassComp;