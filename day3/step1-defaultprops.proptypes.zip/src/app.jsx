import { Component } from "react";
import ChildComp from "./components/child";

class App extends Component{
    render(){
        return <div>
                    <h1>Hello React</h1>
                    <ChildComp city="Bengaluru" sales={Math.round(Math.random() * 100)} version={101} title="Child Comp 1"/>
                    <ChildComp city="Mangalore" sales={Math.round(Math.random() * 100)} version={102} title="Child Comp 1"/>
                    <ChildComp city="Mumbai" sales={10} version={103} title="Child Comp 1"/>
                    <ChildComp city="Delhi" sales={Math.round(Math.random() * 100)}  version={104}  title="Child Comp 1"/>
                    <ChildComp city="Hyderabad" sales={Math.round(Math.random() * 100)} version={105} title="Last but one comp" />
                    <ChildComp city="Chennai" sales={20} version={106} title="Last Component" />
               </div>
    }
}

export default App;