import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
    /* 
    static defaultProps = {
        version : "001",
        city : "Mysore",
        sales : 0,
        title : "Yet to be assigned",
    } 
    */
   static propTypes = {
    version : PropTypes.number.isRequired,
    city : PropTypes.string.isRequired,
    sales : PropTypes.number.isRequired,
    title : PropTypes.string.isRequired
   }
    render(){
        return <div style={ { width:"400px", float:"left", fontFamily : "arial", fontSize : "20px", border : "2px solid red", padding :'20px', margin:"10px" } }>
                    <h3>Child Component : Version { this.props.version }</h3>
                    <h4>{ this.props.title }</h4>
                    <ul>
                        <li>Sales { this.props.sales * 2 }</li>
                        <li>Version { this.props.version }</li>
                        <li>Version { this.props.version }</li>
                        <li>Version { this.props.version }</li>
                        <li>Version { this.props.version }</li>
                        <li>Version { this.props.version }</li>
                        <li>Version { this.props.version }</li>
                        <li>City { this.props.city }</li>
                    </ul>
               </div>
    }
}

/* 
ChildComp.defaultProps = {
    version : "002",
    city : "Mysore",
    sales : 0,
    title : "Yet to be assigned",
}
 */
export default ChildComp;


/* let ChildComp = ({sales,version,city,title}) => {
    return <div style={ { fontFamily : "arial", fontSize : "30px", border : "2px solid red", padding :'20px' } }>
                <h2>Child Fun Component</h2>
                <h3>{ title }</h3>
                <ul>
                    <li>Sales { sales }</li>
                    <li>Version { version }</li>
                    <li>City { city }</li>
                </ul>
            </div>

}

export default ChildComp; */