import React, { Component } from "react";
import axios from "axios";

class App extends Component{
    state = {
        user : []
    }
    render(){
        return <div className="container">
                    <h1>Hello React</h1>
                    {/* <ul>
                        { this.state.user.map(val => <li key={val.id}>{ val.first_name +" "+val.last_name }</li>)}
                    </ul> */}
                    <button className="btn btn-primary" onClick={ ()=> this.getData(1) }>Get First Data</button>
                    &nbsp;
                    &nbsp;
                    <button className="btn btn-primary" onClick={ ()=> this.getData(2) }>Get Second Data</button>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th>Sl #</th>
                                <th>Full Name</th>
                                <th>Photo</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.user.map((val, idx) => <tr key={ val.id }>
                                                                    <td>{ idx+1 }</td>
                                                                    <td>{ val.first_name+" "+val.last_name }</td>
                                                                    <td>
                                                                        <img width="50" src={ val.avatar } alt={ val.first_name+" "+val.last_name } />
                                                                    </td>
                                                                </tr>)
                            }
                        </tbody>
                    </table>
                </div>
    }
    getData = (num) => {
        axios.get("https://reqres.in/api/users?page="+num)
       .then( res => {
             console.log(res.data.data);
            this.setState(()=>{ 
                return {user : res.data.data }
             }, ()=>{
                console.log(this.state.user)
            });
       })
       .catch(err => console.log("Error ", err))
    }
    /* componentDidMount(){
       axios.get("https://reqres.in/api/users?page=1")
       .then( res => {
             console.log(res.data.data);
            this.setState(()=>{ 
                return {user : res.data.data }
             }, ()=>{
                // console.log("data recieved");
                // console.log(this.state.user)
                console.log(this.state.user)
            });
       })
       .catch(err => console.log("Error ", err))
    } */
}

export default App;


/* 
async function myfun(){
     return await Promise().resolve("resolve data from promise")
};
*/
/* 
async function myfun(){
     return await axios.get("https://reqres.in/api/users?page=2")
};

myfun().catch(res => console.log(res)) 
*/