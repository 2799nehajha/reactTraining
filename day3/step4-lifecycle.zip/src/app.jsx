import React, { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    state = {
        appTitle : "App Component",
        appPower : 5
    }
    constructor(){
        super();
        console.log("App Component's constructor was called")
    }
    static getDerivedStateFromProps(){
        console.log("App Component's getDerivedStateFromProps was called");
        return {}
    }
    shouldComponentUpdate(){
        console.log("App Component's shouldComponentUpdate was called");
        return true
    }
    render(){
        console.log("App Component's render was called")
        return <div>
                    <h1>Hello React</h1>
                    <h2>App Power is : { this.state.appPower }</h2>
                    <input type="number" value={this.state.appPower} 
                    onChange={(event) => this.setState({ appPower : Number(event.target.value) })} />
                    <input value={this.state.appTitle} 
                    onChange={(event) => this.setState({ appTitle : event.target.value })} />
                    <button onClick={() => this.setState({appPower : 5})}>set power to 5</button>
                    <hr />
                    { this.state.appPower <= 20 && <ChildComp atitle={this.state.appTitle} apower={ this.state.appPower }/> }
               </div>
    }
    componentDidMount(){
        console.log("App Component's componentDidMount was called");
    }
    
}

export default App;