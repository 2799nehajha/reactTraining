import React, { Component } from "react";

class App extends Component{
    state = {
        strength : 0
    }

    ipref = React.createRef();

    constructor(){
        super();
        // this.increaseStrength = this.increaseStrength.bind(this);
    }
    render(){
        return <div>
                    <h1>Hello React</h1>
                    <h2>Strength : { this.state.strength }</h2>
                    {/* <button onClick={ () => this.increaseStrength() }>Increase Strength</button> */}
                    <button onClick={ this.increaseStrength }>Increase Strength</button>
                    <button onClick={ this.decreaseStrength }>Decrease Strength</button>
                    <br/>
                    <br/>
                    <input ref={this.ipref} type="number" />
                    <button onClick={ this.setStrength }>Set Strength</button>
                    <br/>
                    <br/>
                    <input value={ this.state.strength } 
                    onChange={(event) => this.setState({ strength : parseInt(event.target.value) })} 
                    type="number" />
                    <br/>
                    <br/>
                    <input value={ this.state.strength } onChange={ (event) => this.setState({strength : Number(event.target.value) })} type="range" />
                </div>
    }
    increaseStrength = () => {
        this.setState({
            strength : this.state.strength+1
        })
    }
    decreaseStrength = () => {
        this.setState({
            strength : this.state.strength-1
        })
    }
    setStrength = () => {
        this.setState({
            strength : Number(this.ipref.current.value)
            // strength : parseInt(this.ipref.current.value)
        })
    }
}

export default App;