import ChildComp from "./components/child.component";
import useToggle from "./hooks/usetoggle";

let App = () => {
  // console.log(useToggle());// 
  let [show, setShow] = useToggle(true)
  return (
    <div>
      <h1>Hooks Custom</h1>
      <button onClick={()=> setShow(!show)}>Show / Hide</button>
      { show ? <ChildComp/> : "Component is hidden"}
    </div>
  );
}

export default App;