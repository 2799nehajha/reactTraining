import { BrowserRouter, NavLink, Route, Routes } from "react-router-dom";
import "./assets/mystyle.css";
import React from "react";
import { useState } from "react";
import { Suspense } from "react";
/* 
import HomeComp from "./components/home";
import BatmanComp from "./components/batman";
import SupermanComp from "./components/superman";
import FlashComp from "./components/flash";
import NotFoundComp from "./components/notfound";
import Batmanmovie1Comp from "./components/batmanmovie1";
import Batmanmovie2Comp from "./components/batmanmovie2"; 
*/
let HomeComp  = React.lazy(() => import("./components/home") ) ;
let BatmanComp  = React.lazy(() => import("./components/batman") ) ;
let SupermanComp  = React.lazy(() => import("./components/superman") ) ;
let FlashComp  = React.lazy(() => import("./components/flash") ) ;
let NotFoundComp  = React.lazy(() => import("./components/notfound") ) ;
let Batmanmovie1Comp  = React.lazy(() => import("./components/batmanmovie1") ) ;
let Batmanmovie2Comp  = React.lazy(() => import("./components/batmanmovie2") ) ; 


let App = () => {
  let [quantity, setQuantity] = useState(10)
  return (
    <div className="container">
      <h1>Routes in React</h1>
      <hr />
      <BrowserRouter>
      <ul className="nav">
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/">Home</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/batman">Batman</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/batman/movie1">Batman Movie 1</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/batman/movie2">Batman Movie 2</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/superman">Superman</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to={'/flash/'+quantity}>Flash</NavLink> </li>
       <li className="nav-item"> <NavLink className={ ({isActive}) => isActive ? "nav-link box" : "nav-link"} to="/hulk">Hulk</NavLink> </li>
      </ul>
      <Routes>
        <Route path="/" element={<Suspense fallback={<>loading...</>}> <HomeComp/> </Suspense>} />
        <Route path="/batman" element={<Suspense fallback={<>loading...</>}> <BatmanComp/> </Suspense>}>
          <Route path="/batman/movie1" element={<Suspense fallback={<>loading...</>}> <Batmanmovie1Comp/> </Suspense>} />
          <Route path="/batman/movie1" element={<Suspense fallback={<>loading...</>}> <Batmanmovie2Comp/> </Suspense>} />
        </Route>
        <Route path="/superman" element={<Suspense fallback={<>loading...</>}> <SupermanComp/> </Suspense>} />
        <Route path="/flash/:qty" element={<Suspense fallback={<>loading...</>}> <FlashComp/> </Suspense>} />
        <Route path="*" element={<Suspense fallback={<>loading...</>}> <NotFoundComp/> </Suspense>} />
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;