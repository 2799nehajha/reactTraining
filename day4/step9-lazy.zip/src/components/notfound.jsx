let NotFoundComp = () => {
    return <div>
                <h2>404 Requested Component Not Found</h2>
            </div>
}

export default NotFoundComp