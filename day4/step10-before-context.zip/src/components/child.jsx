let ChildComp = (props) => {
    return <div style={ {border : "2px solid red", padding : "10px"} }>
                <h2>Child Component</h2>
                <h4>Grandparent's message is : {props.message}</h4>
            </div>
}

export default ChildComp