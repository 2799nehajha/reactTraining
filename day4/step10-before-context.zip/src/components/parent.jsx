import ChildComp from "./child"

let ParentComp = (props) => {
    return <div style={ {border : "2px solid red", padding : "10px"} }>
                <h2>Parent Component</h2>
                <ChildComp message={props.message}/>
            </div>
}

export default ParentComp