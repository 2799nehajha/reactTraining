import GrandParentComp from "./components/grandparent";

let App = () => {
  return (
    <div className="container">
      <h1>Context in React</h1>
      <hr />
      <GrandParentComp></GrandParentComp>
    </div>
  );
}

export default App;