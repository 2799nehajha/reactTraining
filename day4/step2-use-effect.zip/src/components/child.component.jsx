import { useEffect, useState } from "react";

let ChildComp = (prop) => {
  let [version, setVersion] = useState(0)
  // component mount
  useEffect(()=> {
    console.log("ChildComp Component Mounted");
  },[]);
  // component update
  useEffect(()=> {
    console.log("ChildComp Component was Updated",prop.power);
  },[prop.power, version]);
  // component unmount
  useEffect(()=> {
    return () =>  console.log("ChildComp Component was Un-Mounted");
  },[]);
    return <div>
                <h2>Child Component</h2>
                <h3>Title : {prop.title}</h3>
                <h3>Power : {prop.power}</h3>
                <h3>Version : {version}</h3>
                <button onClick={() => prop.setPower(10)}>I want to set my own power</button>
                <button onClick={() => setVersion(Math.round(Math.random() * 100))}>setVersion</button>
            </div>
};

export default ChildComp;