import { useState } from "react";
import ChildComp from "./components/child.component";

let App = () => {
  let [appPower, setPower] = useState(0);
  let [appTitle, setTitle] = useState("");
  let [show, toggleComp] = useState(true);

  return (
    <div>
      <h1>Hooks Lifecycle</h1>
      <input value={appPower} type="range" onChange={(event) => setPower(Number(event.target.value))} />
      <button onClick={()=> toggleComp(!show)}>Show / Hide</button>
      <button onClick={()=> {
        let titles = ["title 1", 'title 2', 'title 3', 'title 4'];
        setTitle(titles[Math.floor(Math.random() * titles.length )]);
      }}>Set Random Title</button>
      { show ? <ChildComp setPower={setPower} title={appTitle} power={appPower}/> : "Child Component is hidden" }
    </div>
  );
}

export default App;