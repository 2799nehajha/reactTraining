import { useEffect, useState } from "react";
import axios from "axios";

/* 
username : uname,
userage : uage,
usermail : umail,
usercity : ucity
*/
let ChildComp = (prop) => {
    let [users, setUsers] = useState([{_id : 0, username : "", userage :"", usermail:"", usercity:""}])
    // component mount
    useEffect(()=> {
        console.log("ChildComp Component Mounted");
        axios.get("http://localhost:6060/data").then(res => {
            // setUsers(Object.assign(users, res.data));
            // setUsers([res.data]);
            // console.log(res.data);
            setUsers(res.data)
        })
    },[]);
    return <div>
                <h2>Child Component</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Sl #</th>
                            <th>User Name</th>
                            <th>User Age</th>
                            <th>User eMail</th>
                            <th>User City</th>
                        </tr>
                    </thead>
                    <tbody>
                        { users.map((val, idx) => <tr key={val._id}>
                            <td>{idx + 1}</td>
                            <td>{val.username}</td>
                            <td>{val.userage}</td>
                            <td>{val.usermail}</td>
                            <td>{val.usercity}</td>
                        </tr> )}
                    </tbody>
                </table>
            </div>
};

export default ChildComp;