import { useState } from "react";
import axios from "axios";

let FormComponent = () => {
    let [uname, setName] = useState("");
    let [uage, setAge] = useState("");
    let [umail, setMail] = useState("");
    let [ucity, setCity] = useState("");

    let submitHandler = () => {
        if(uage < 18){
            alert("you are too young to join us")
        }else if(uage > 90){
            alert("you are too old to join us")
        }else{
            axios
            .post("http://localhost:6060/data", {
                username : uname,
                userage : uage,
                usermail : umail,
                usercity : ucity
            })
            .then(res => console.log(res))
        }
    }
    return <div>
                <h2>Registeration Form</h2>
                <div className="mb-3">
                    <label htmlFor="uname" className="form-label">User Name</label>
                    <input value={uname} onChange={(evt) => setName(evt.target.value)} className="form-control" id="uname"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="uage" className="form-label">User Age</label>
                    <input value={uage} onChange={(evt) => setAge(evt.target.value)} type="number" className="form-control" id="uage"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="umail" className="form-label">User eMail</label>
                    <input value={umail} onChange={(evt) => setMail(evt.target.value)} className="form-control" id="umail"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="ucity" className="form-label">User City</label>
                    <input value={ucity} onChange={(evt) => setCity(evt.target.value)} className="form-control" id="ucity"/>
                </div>
                <button onClick={()=> submitHandler() } className="btn btn-primary mb-3">Register</button>
                <hr />
                <ul>
                    <li>User Name {uname}</li>
                    <li>User Age {uage}</li>
                    <li>User Mail {umail}</li>
                    <li>User City {ucity}</li>
                </ul>
            </div>
};

export default FormComponent;
