import ChildComp from "./components/childcomp";
import FormComponent from "./components/form.component";

let App = () => {
  return (
    <div className="container">
      <h1>Form Component</h1>
      <FormComponent/>
      <ChildComp/>
    </div>
  );
}

export default App;