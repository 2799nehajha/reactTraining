/* 
server that connects to mongoDB 
create read update and delete
express : web server
mongoose : ORM 
CORS : node 6060 / react 5050
*/

let express = require("express");
let mongoose = require("mongoose");
let cors = require("cors");

let config = require("./config.json");
let app = express();
app.use(express.json());
app.use(cors());

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let Hero = mongoose.model("Hero", Schema({
    id : ObjectId,
    username : String,
    userage : String,
    usermail : String,
    usercity : String
}));
let localDB = "mongodb://localhost:27017/socgenDB";
let cloudDB = "mongodb+srv://admin:xYeAuJgQB6c72d4d@cluster0.am2gixs.mongodb.net/socgenDB?retryWrites=true&w=majority&appName=Cluster0";
mongoose.connect(cloudDB)
.then(res => console.log("DB Connected"))
.catch(error => console.log("Error ", error))

/* setTimeout(() => {
    Hero.find().then(dbres => console.log("Response ", dbres))
},2000) */

// let data = {"page":2,"per_page":6,"total":12,"total_pages":2,"data":[{"id":7,"email":"michael.lawson@reqres.in","first_name":"Michael","last_name":"Jackson","avatar":"https://reqres.in/img/faces/7-image.jpg"},{"id":8,"email":"lindsay.ferguson@reqres.in","first_name":"Lindsay","last_name":"Ferguson","avatar":"https://reqres.in/img/faces/8-image.jpg"},{"id":9,"email":"tobias.funke@reqres.in","first_name":"Tobias","last_name":"Funke","avatar":"https://reqres.in/img/faces/9-image.jpg"},{"id":10,"email":"byron.fields@reqres.in","first_name":"Byron","last_name":"Fields","avatar":"https://reqres.in/img/faces/10-image.jpg"},{"id":11,"email":"george.edwards@reqres.in","first_name":"George","last_name":"Edwards","avatar":"https://reqres.in/img/faces/11-image.jpg"},{"id":12,"email":"rachel.howell@reqres.in","first_name":"Rachel","last_name":"Howell","avatar":"https://reqres.in/img/faces/12-image.jpg"}],"support":{"url":"https://reqres.in/#support-heading","text":"To keep ReqRes free, contributions towards server costs are appreciated!"}}

app.get("/", function(req, res){
    res.send("hello from express");
});

app.get("/data", function(req, res){
    Hero.find().then(dbres => {
        res.send(dbres);
    })
});

app.post("/data", function(req, res){
   let hero = new Hero(req.body);
   hero.save()
   .then(dbres => {
    console.log(dbres);
    res.send({message : dbres.username+" was added"})
   })
   .catch(error => console.log("Error ", error) )
});

app.listen(config.port, config.host, (error) => {
    if(error) { console.log("Error ", error)}
    else { console.log("web server is now live on ",config.host,":",config.port)}
})


/* 
update
    get existing info
    patch updated info
delete
*/