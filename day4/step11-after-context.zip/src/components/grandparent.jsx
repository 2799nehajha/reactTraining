import { useRef, useState } from "react"
import ParentComp from "./parent";
import { FamilyContext } from "../contexts/familycontext";

let GrandParentComp = () => {
let [message, setMessage] = useState("default message");
let messageRef = useRef();
    return <div style={ {border : "2px solid red", padding : "10px"} }>
                <h2>Grand Parent Component</h2>
                <h3>Message : {message}</h3>
                <input ref={messageRef} type="text" />
                <button onClick={()=> setMessage(messageRef.current.value) }>Change Message</button>
                <hr />
                <FamilyContext.Provider value={message} >
                    <ParentComp/>
                </FamilyContext.Provider>
            </div>
}

export default GrandParentComp