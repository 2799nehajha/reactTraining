import ChildComp from "./child"

let ParentComp = () => {
    return <div style={ {border : "2px solid red", padding : "10px"} }>
                <h2>Parent Component</h2>
                <ChildComp/>
            </div>
}

export default ParentComp