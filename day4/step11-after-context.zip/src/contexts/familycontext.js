import React from "react";

let FamilyContext = React.createContext();
/* 
let Consumer = FamilyContext.Consumer;
let Provider = FamilyContext.Provider; 
*/

export { FamilyContext }