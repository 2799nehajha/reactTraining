import { useRef, useState } from "react";

let Avengers = () => {
    let [avenger, setAvenger ] = useState({ firstname : "hello", lastname : "world" });
    let fn = useRef();
    let ln = useRef();
    return <div>
                <h2>Avengers Component</h2>
                <input ref={fn} type="text" />
                <button onClick={() => setAvenger({...avenger, firstname : fn.current.value })}>Add First Name</button>
                <br />
                <br />
                <input ref={ln} type="text" />
                <button onClick={() => setAvenger({...avenger, lastname : ln.current.value })}>Add Last Name</button>
                <hr />
                <p>First Name : {avenger.firstname}</p>
                <p>Last Name : {avenger.lastname}</p>
           </div>
};

export default Avengers;