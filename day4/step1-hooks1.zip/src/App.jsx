import Avengers from "./components/avengers";
import ChildComp from "./components/childcomp";
import Heroes from "./components/heroes";

let App = () => <div>
                  <h1>Function Component</h1>
                  <ChildComp version={101} sales={56} city="Bengaluru" title="First Child Component"/>
                  <Heroes/>
                  <Avengers/>
                </div>

export default App;