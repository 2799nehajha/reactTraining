import { useReducer, useRef, useState } from "react";

let ChildComp = (prop) => {

    /*     
    let [herotitle, setHeroTitle] = useState("Batman");
    */

    // reducerHook
    // reducer fun
    // action to denote what we want to update

    let reducerFun = (state,action) => {
        switch(action.type){
            case "CHANGE_TITLE" : return {...state, title : action.payload }
            case "CHANGE_POWER" : return {...state, power : action.payload }
            case "CHANGE_CITY" : return {...state, city : action.payload }
            case "CHANGE_MOVIE" : return {...state, movie : action.payload }
            default : return state
        }
    }
   
    let [store, dispatch] = useReducer(reducerFun, {title : "default title", power : 0, city : "Bengaluru", movie : 0});
    let titleRef = useRef();
    let powerRef = useRef();
    let cityRef = useRef();
    return <div>
                <h2>Child Component</h2>
                <input ref={titleRef} type="text" />
                <button onClick={() => dispatch({type : "CHANGE_TITLE", payload : titleRef.current.value })}>Change Title</button>
                <br />
                <input ref={powerRef} type="number" />
                <button onClick={() => dispatch({type : "CHANGE_POWER", payload : Number(powerRef.current.value) })}>Change Power</button>
                <br />
                <input ref={cityRef} type="text" />
                <button onClick={() => dispatch({type : "CHANGE_CITY", payload : cityRef.current.value })}>Change City</button>
                <br />
                <input type="number" onChange={(event) => dispatch({type : "CHANGE_MOVIE", payload : Number(event.target.value) })} />

                <br />
                <ul>
                    <li>Title : {store.title}</li>
                    <li>Power : {store.power}</li>
                    <li>City : {store.city}</li>
                    <li>Movie : {store.movie}</li>
                </ul>
            </div>
};

export default ChildComp;