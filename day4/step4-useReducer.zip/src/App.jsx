import ChildComp from "./components/child.component";

let App = () => {
  return (
    <div>
      <h1>Hooks Lifecycle</h1>
      <ChildComp/>
    </div>
  );
}

export default App;