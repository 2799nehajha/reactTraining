let HomeComp = () => {
    return <div>
                <h2>Home Component</h2>
            </div>
}

export default HomeComp