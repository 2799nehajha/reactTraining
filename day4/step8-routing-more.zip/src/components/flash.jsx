import { useParams } from "react-router-dom"
let FlashComp = () => {
    let params = useParams();
    return <div>
                <h2>Flash Component</h2>
                <h3>Quantity is : {params.qty}</h3>
            </div>
}

export default FlashComp