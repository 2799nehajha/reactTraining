import { useEffect, useState } from "react";
import axios from "axios";

let ChildComp = (prop) => {
    let [users, setUsers] = useState({ data : [{id : 0, email : "vijay.shivu@gmail.com", first_name :"Vijay", last_name:"Shivakumar", avatar:"https://avatars.githubusercontent.com/u/95652257?s=400&u=14e5b8bc1877bffbee2169ec2358ddeaac14850d&v=4"}] })
    // component mount
    useEffect(()=> {
        console.log("ChildComp Component Mounted");
        axios.get("https://reqres.in/api/users?page=2").then(res => {
            // setUsers(Object.assign(users, res.data));
            setUsers({data: [...users.data, ...res.data.data]});
            console.log(users);
        })
    },[]);
    return <div>
                <h2>Child Component</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Sl #</th>
                            <th>eMail</th>
                            <th>Full Name</th>
                            <th>Avatar</th>
                        </tr>
                    </thead>
                    <tbody>
                        { users.data.map((val) => <tr key={val.id}>
                            <td>{val.id}</td>
                            <td>{val.email}</td>
                            <td>{val.first_name+" "+val.last_name}</td>
                            <td>
                                <img width="80" src={val.avatar} alt={val.first_name+" "+val.last_name} />
                            </td>
                        </tr> )}
                    </tbody>
                </table>
            </div>
};

export default ChildComp;