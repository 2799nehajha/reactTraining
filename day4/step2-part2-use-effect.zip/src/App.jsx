import { useState } from "react";
import ChildComp from "./components/child.component";

let App = () => {
  let [appPower, setPower] = useState(0);
  let [appTitle, setTitle] = useState("");
  let [show, toggleComp] = useState(true);
  
  let setPowerorTitle = function(){
    if(arguments[0] === 5){
      setPower(arguments[0])
    }else if(arguments[0] === "New Title"){
      setTitle(arguments[0])
    }else{
      console.log("the accepted values are 5 or New Title")
    }
  }

  return (
    <div>
      <h1>Hooks Lifecycle</h1>
      <input value={appPower} type="range" onChange={(event) => setPower(Number(event.target.value))} />
      <button onClick={()=> toggleComp(!show)}>Show / Hide</button>
      <button onClick={() => setPowerorTitle(5)}>Set Power via Function</button>
      <button onClick={() => setPowerorTitle("New Title")}>Set Title via Function</button>
      <button onClick={() => setPowerorTitle("hello soc gen")}>Set random Title via Function</button>
      <button onClick={()=> {
        let titles = ["title 1", 'title 2', 'title 3', 'title 4'];
        setTitle(titles[Math.floor(Math.random() * titles.length )]);
      }}>Set Random Title</button>
      { show ? <ChildComp setPower={setPower} title={appTitle} power={appPower}/> : "Child Component is hidden" }
    </div>
  );
}

export default App;